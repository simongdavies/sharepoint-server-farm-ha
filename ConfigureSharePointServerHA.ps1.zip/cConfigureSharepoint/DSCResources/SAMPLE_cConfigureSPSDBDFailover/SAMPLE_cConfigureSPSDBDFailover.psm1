﻿function Get-TargetResource 
{
    [CmdletBinding()]
    [OutputType([Hashtable])]
    param(
         [Parameter(Mandatory=$true)]
        [string[]]$DatabaseNames,
        [Parameter(Mandatory=$true)]
        [string]$FailoverServerInstance
    )


    $returnValue= @{
        DatabaseNames = $DatabaseNames
        FailoverServerInstance=$FailoverServerInstance
    }
}
function Set-TargetResource 
{
    [CmdletBinding()]
     param(
         [Parameter(Mandatory=$true)]
        [string[]]$DatabaseNames,
        [Parameter(Mandatory=$true)]
        [string]$FailoverServerInstance
    )
    try 
    {
        AddSharePointPsSnapin
        ForEach ($DatabaseName in $DatabaseNames)
        {
            Update-SPFailOverInstance -DatabaseName $DatabaseName -FailoverServerInstance $FailoverServerInstance
        }
    }
    catch
    {
        Write-Verbose "Failed to update failover instance for database $DatabaseName"
    }
}
function Test-TargetResource 
{
    [CmdletBinding()]
    param(
         [Parameter(Mandatory=$true)]
        [string[]]$DatabaseNames,
        [Parameter(Mandatory=$true)]
        [string]$FailoverServerInstance
    )


   $false
}
function Update-SPFailOverInstance
{
    param(
        [Parameter(Mandatory=$true)]
        [string]$DatabaseName,
        [Parameter(Mandatory=$true)]
        [string]$FailoverServerInstance
    )
    
    try 
    {
        Get-SPDatabase | ForEach-Object 
        {
            If ($_.Name -eq $DatabaseName)
            {
                $_.AddFailoverServiceInstance($FailoverServerInstance)
                $_.Update()
                Write-Verbose -Message "Updated database failover instance for '$($_.Name)'."                
            }
        }
    }
    catch
    {
            Write-Verbose -Message "FAILED: Updating database failover instance for '$($_.Name)'."  
    }
}

Export-ModuleMember -function *-TargetResource